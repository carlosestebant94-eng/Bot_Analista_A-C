"""
config/__init__.py
Módulo de configuración
"""
from .settings import Settings

__all__ = ['Settings']
