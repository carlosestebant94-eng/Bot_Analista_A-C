"""
telegram_bot/__init__.py
Módulo del bot de Telegram
"""
from .bot import TelegramAnalystBot

__all__ = ['TelegramAnalystBot']
